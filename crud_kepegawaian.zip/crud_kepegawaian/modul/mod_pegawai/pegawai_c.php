<?php
    require_once '../../../josys/db_connect.php';
    include_once '../../../josys/class/Database.php';

    $database   = new Database($db);

    $module = $_GET['module'];
    $act    = $_GET['act'];

    if($act=='insert')
    {
        // Insert
        if ($module=='pegawai' AND $act=='insert')
        {

            //data yang akan di insert berbentuk array
            $form_data = array(
                "nip"           => "$_POST[nip]",
                "nama"          => "$_POST[nama]",
                "id_jabatan"    => "$_POST[id_jabatan]",
                "id_kontrak"    => "$_POST[id_kontrak]"
            );

            //proses insert ke database
            $database->insert($table="pegawai", $array=$form_data);
            
            echo "<script> window.location = '../../media.php?module=$module';</script>";
        }
        else
        {
            echo "<script>alert('Maaf! Data Gagal Disimpan, Silahkan coba lagi.'); window.location = '../../media.php?module=$module';</script>";
        }
    }

    if($act=='update')
    {
        // Update
        if ($module=='pegawai' AND $act=='update')
        {
            
            //data yang akan diupdate berbentuk array
            $form_data = array(
                "nip"           => "$_POST[nip]",
                "nama"          => "$_POST[nama]",
                "id_jabatan"    => "$_POST[id_jabatan]",
                "id_kontrak"    => "$_POST[id_kontrak]"
            );

            //proses update ke database
            $database->update($table="pegawai", $array=$form_data, $fields_key="id_pegawai", $id="$_POST[id]");

            echo "<script> window.location = '../../media.php?module=$module';</script>";
        }
        else
        {
            echo "<script>alert('Maaf! Data Gagal Disimpan, Silahkan coba lagi.'); window.location = '../../media.php?module=$module';</script>";
        }
    }

    if($act=='delete')
    {
        // Delete
        if ($module=='pegawai' AND $act=='delete')
        {
            $database->delete($table="pegawai", $fields_key="id_pegawai", $id="$_GET[id]");
            
            echo "<script> window.location = '../../media.php?module=$module';</script>";
        }
        else
        {
            echo "<script>alert('Maaf! Data Gagal Dihapus, Silahkan coba lagi.'); window.location = '../../media.php?module=$module';</script>";
        }
    }
?>