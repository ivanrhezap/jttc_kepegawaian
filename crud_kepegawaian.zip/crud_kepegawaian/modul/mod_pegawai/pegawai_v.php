<script src="assets/vendors/input-mask/input-mask.min.js"></script>
<!--Begin DataTables-->
<link rel="stylesheet" href="assets/vendors/dataTables/css/jquery.dataTables.css" type="text/css" media="screen" />
<script type="text/javascript" charset="utf8" src="assets/vendors/dataTables/js/jquery.dataTables.js"></script>
<script type="text/javascript" language="javascript" src="assets/vendors/dataTables/js/jquery.dataTables.min.js"></script>
<script>
$(document).ready(function() {
    $('#datatables').DataTable({
    "lengthMenu": [[25, 50, -1], [25, 50, "All"]]
    } );
} );
</script>

<?php
    $aksi="modul/mod_pegawai/pegawai_c.php?module=pegawai";
    if (!isset($_GET['act'])) {
        $_GET['act'] = '';
    }
    switch($_GET['act']){
    default:
?>
        <div class="card">
            <div class="card-body card-padding">
                <p class="c-black f-500 m-b-20">Pegawai
                    <a href="?module=pegawai&act=add" class="btn bgm-deeppurple btn-sm waves-effect pull-right"><i class="zmdi zmdi-plus zmdi-hc-fw"></i> Create</a>
                </p>

                <hr class="line">

                <div class="table-responsive">
                    <table class='display' id='datatables'>
                        <thead>
                            <tr>
                                <th width="5%">No</th>
                                <th>NIP</th>
                                <th>Nama</th>
                                <th>Jabatan</th>
                                <th>Kontrak</th>
                                <th width="150px">Aksi</th>
                            </tr>
                        </thead>

                        <tbody>
                        <?php
                            $no = 1;
                            $posts = $database->select($fields="*", $table="pegawai", $where_clause="ORDER BY id_pegawai ASC", $fetch="all");
                            foreach ($posts as $key => $value) {
                                $jab = $database->select($fields="nama", $table="jabatan", $where_clause="WHERE id_jabatan = '$value[id_jabatan]'", $fetch="");
                                $kon = $database->select($fields="nama", $table="kontrak", $where_clause="WHERE id_kontrak = '$value[id_kontrak]'", $fetch="");
                        ?>
                            <tr>
                                <th><?php echo $key + 1; ?></th>
                                <td><?php echo $value['nip']; ?></td>
                                <td><?php echo $value['nama']; ?></td>
                                <td><?php echo $jab['nama']; ?></td>
                                <td><?php echo $kon['nama']; ?></td>
                                <td>
                                    <a href="?module=pegawai&act=edit&id=<?php echo $value['id_pegawai'];?>" class="btn bgm-teal waves-effect"><i class="zmdi zmdi-edit zmdi-hc-fw"></i> Edit</a>                                            
                                    <a href="<?php echo "$aksi&act=delete&id=$value[id_pegawai]";?>" class="btn bgm-pink waves-effect" onclick="return confirm('Apakah anda yakin menghapus data ini?');"><i class="zmdi zmdi-delete zmdi-hc-fw"></i> Delete</a>
                                </td>
                            </tr>
                        <?php
                                $no++;
                            }
                        ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

<?php
    break;
    case "add":
?>
        <div class="card">
            <div class="card-body card-padding">
            <p class="c-black f-500 m-b-20">Pegawai / Create</p>
                <hr class="line">

                <form id="staff_gallery-form" method="post" enctype="multipart/form-data" action="<?php echo $aksi; ?>&act=insert">
                    <div class="row">
                        
                        <div class="col-md-6">
                            <div class="form-group">
                                <div class="fg-line">
                                    <label>NIP</label>
                                    <input type="text" name="nip" class="form-control" placeholder="Masukkan nip" required="require">
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <div class="fg-line">
                                    <label>Nama</label>
                                    <input type="text" name="nama" class="form-control" placeholder="Masukkan nama" required="require">
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <div class="fg-line">
                                    <label>Jabatan</label>
                                    <div class="select">
                                        <select class="form-control" name="id_jabatan" required="require">
                                            <option disabled="disable" selected="select">- Pilih -</option>
                                        <?php
                                            $jab = $database->select($fields='*', $table='jabatan', $where_clause='ORDER BY nama ASC', $fetch='all');
                                            foreach ($jab as $key => $jab_val) {
                                                echo '<option value="'.$jab_val['id_jabatan'].'">'.$jab_val['nama'].'</option>';
                                            }
                                        ?>
                                        </select>
                                    </div>
                                </div>
                            </div>                                            
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <div class="fg-line">
                                    <label>Kontrak</label>
                                    <div class="select">
                                        <select class="form-control" name="id_kontrak" required="require">
                                            <option disabled="disable" selected="select">- Pilih -</option>
                                        <?php
                                            $kon = $database->select($fields='*', $table='kontrak', $where_clause='ORDER BY nama ASC', $fetch='all');
                                            foreach ($kon as $key => $kon_val) {
                                                echo '<option value="'.$kon_val['id_kontrak'].'">'.$kon_val['nama'].'</option>';
                                            }
                                        ?>
                                        </select>
                                    </div>
                                </div>
                            </div>                                            
                        </div>
                    </div>

                    <div class="form-group kaki">
                        <button type="submit" class="btn btn-primary btn-sm m-t-10 waves-effect"><i class="zmdi zmdi-check"></i> Save</button>
                        <button type="button" class="btn btn-danger btn-sm m-t-10 waves-effect" onclick="self.history.back()"><i class="zmdi zmdi-close"></i> Cancel</button>
                    </div>

                </form>
            </div>
        </div>

<?php
    break;
    case "edit":
    $id         = $_GET['id'];
    $value      = $database->select($fields="*", $table="pegawai", $where_clause="WHERE id_pegawai = '$id'", $fetch="");
?>
        <div class="card">

            <div class="card-body card-padding">
            <p class="c-black f-500 m-b-20">Pegawai / Edit</p>
                <hr class="line">

                <form id="staff_gallery-form" method="post" enctype="multipart/form-data" action="<?php echo $aksi; ?>&act=update">
                    <div class="row">
                        <input type="hidden" name="id" value="<?php echo $id; ?>">
                        <div class="col-md-6">
                            <div class="form-group">
                                <div class="fg-line">
                                    <label>NIP</label>
                                    <input type="text" name="nip" class="form-control" placeholder="Masukkan nip" value="<?php echo $value['nip']; ?>">
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <div class="fg-line">
                                    <label>Nama</label>
                                    <input type="text" name="nama" class="form-control" placeholder="Masukkan nama" value="<?php echo $value['nama']; ?>">
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <div class="fg-line">
                                    <label>Jabatan</label>
                                    <div class="select">
                                        <select class="form-control" name="id_jabatan" required="require">
                                            <option disabled="disable">- Pilih -</option>
                                        <?php
                                            $jab = $database->select($fields='*', $table='jabatan', $where_clause='ORDER BY nama ASC', $fetch='all');
                                            foreach ($jab as $key => $jab_val) {
                                                if ($jab_val['id_jabatan']==$value['id_jabatan']) {
                                                    echo '<option value="'.$jab_val['id_jabatan'].'" selected>'.$jab_val['nama'].'</option>';
                                                } else {
                                                    echo '<option value="'.$jab_val['id_jabatan'].'">'.$jab_val['nama'].'</option>';
                                                }
                                            }
                                        ?>
                                        </select>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <div class="fg-line">
                                    <label>Kontrak</label>
                                    <div class="select">
                                        <select class="form-control" name="id_kontrak" required="require">
                                            <option disabled="disable">- Pilih -</option>
                                        <?php
                                            $kon = $database->select($fields='*', $table='kontrak', $where_clause='ORDER BY nama ASC', $fetch='all');
                                            foreach ($kon as $key => $kon_val) {
                                                if ($kon_val['id_kontrak']==$value['id_kontrak']) {
                                                    echo '<option value="'.$kon_val['id_kontrak'].'" selected>'.$kon_val['nama'].'</option>';
                                                } else {
                                                    echo '<option value="'.$kon_val['id_kontrak'].'">'.$kon_val['nama'].'</option>';
                                                }
                                            }
                                        ?>
                                        </select>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="form-group kaki">
                        <button type="submit" class="btn btn-primary btn-sm m-t-10 waves-effect"><i class="zmdi zmdi-check"></i> Save</button>
                        <button type="button" class="btn btn-danger btn-sm m-t-10 waves-effect" onclick="self.history.back()"><i class="zmdi zmdi-close"></i> Cancel</button>
                    </div>

                </form>

            </div>
        </div>
<?php
    break;
    }
?>