<?php
    require_once '../../../josys/db_connect.php';
    include_once '../../../josys/class/Database.php';

    $database   = new Database($db);

    $module = $_GET['module'];
    $act    = $_GET['act'];

    if($act=='insert')
    {
        // Insert
        if ($module=='kontrak' AND $act=='insert')
        {

            //data yang akan di insert berbentuk array
            $form_data = array(
                "nama"          => "$_POST[nama]"
            );

            //proses insert ke database
            $database->insert($table="kontrak", $array=$form_data);
            
            echo "<script> window.location = '../../media.php?module=$module';</script>";
        }
        else
        {
            echo "<script>alert('Maaf! Data Gagal Disimpan, Silahkan coba lagi.'); window.location = '../../media.php?module=$module';</script>";
        }
    }

    if($act=='update')
    {
        // Update
        if ($module=='kontrak' AND $act=='update')
        {
            
            //data yang akan diupdate berbentuk array
            $form_data = array(
                "nama"          => "$_POST[nama]"
            );

            //proses update ke database
            $database->update($table="kontrak", $array=$form_data, $fields_key="id_kontrak", $id="$_POST[id]");

            echo "<script> window.location = '../../media.php?module=$module';</script>";
        }
        else
        {
            echo "<script>alert('Maaf! Data Gagal Disimpan, Silahkan coba lagi.'); window.location = '../../media.php?module=$module';</script>";
        }
    }

    if($act=='delete')
    {
        // Delete
        if ($module=='kontrak' AND $act=='delete')
        {
            $database->delete($table="kontrak", $fields_key="id_kontrak", $id="$_GET[id]");
            
            echo "<script> window.location = '../../media.php?module=$module';</script>";
        }
        else
        {
            echo "<script>alert('Maaf! Data Gagal Dihapus, Silahkan coba lagi.'); window.location = '../../media.php?module=$module';</script>";
        }
    }
?>