<script src="assets/vendors/input-mask/input-mask.min.js"></script>
<!--Begin DataTables-->
<link rel="stylesheet" href="assets/vendors/dataTables/css/jquery.dataTables.css" type="text/css" media="screen" />
<script type="text/javascript" charset="utf8" src="assets/vendors/dataTables/js/jquery.dataTables.js"></script>
<script type="text/javascript" language="javascript" src="assets/vendors/dataTables/js/jquery.dataTables.min.js"></script>
<script>
$(document).ready(function() {
    $('#datatables').DataTable({
    "lengthMenu": [[25, 50, -1], [25, 50, "All"]]
    } );
} );
</script>

<?php
    $aksi="modul/mod_kontrak/kontrak_c.php?module=kontrak";
    if (!isset($_GET['act'])) {
        $_GET['act'] = '';
    }
    switch($_GET['act']){
    default:
?>
        <div class="card">
            <div class="card-body card-padding">
                <p class="c-black f-500 m-b-20">Kontrak
                    <a href="?module=kontrak&act=add" class="btn bgm-deeppurple btn-sm waves-effect pull-right"><i class="zmdi zmdi-plus zmdi-hc-fw"></i> Create</a>
                </p>

                <hr class="line">

                <div class="table-responsive">
                    <table class='display' id='datatables'>
                        <thead>
                            <tr>
                                <th width="5%">No</th>
                                <th>Nama</th>
                                <th width="150px">Aksi</th>
                            </tr>
                        </thead>

                        <tbody>
                        <?php
                            $no = 1;
                            $posts = $database->select($fields="*", $table="kontrak", $where_clause="ORDER BY id_kontrak ASC", $fetch="all");
                            foreach ($posts as $key => $value) {
                        ?>
                            <tr>
                                <th><?php echo $key + 1; ?></th>
                                <td><?php echo $value['nama']; ?></td>
                                <td>
                                    <a href="?module=kontrak&act=edit&id=<?php echo $value['id_kontrak'];?>" class="btn bgm-teal waves-effect"><i class="zmdi zmdi-edit zmdi-hc-fw"></i> Edit</a>
                                    <a href="<?php echo "$aksi&act=delete&id=$value[id_kontrak]";?>" class="btn bgm-pink waves-effect" onclick="return confirm('Apakah anda yakin menghapus data ini?');"><i class="zmdi zmdi-delete zmdi-hc-fw"></i> Delete</a>
                                </td>
                            </tr>
                        <?php
                                $no++;
                            }
                        ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

<?php
    break;
    case "add":
?>
        <div class="card">
            <div class="card-body card-padding">
            <p class="c-black f-500 m-b-20">Kontrak / Create</p>
                <hr class="line">

                <form id="staff_gallery-form" method="post" enctype="multipart/form-data" action="<?php echo $aksi; ?>&act=insert">
                    <div class="row">
                        
                        <div class="col-md-6">
                            <div class="form-group">
                                <div class="fg-line">
                                    <label>Nama</label>
                                    <input type="text" name="nama" class="form-control" placeholder="Masukkan nama" required="require">
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="form-group kaki">
                        <button type="submit" class="btn btn-primary btn-sm m-t-10 waves-effect"><i class="zmdi zmdi-check"></i> Save</button>
                        <button type="button" class="btn btn-danger btn-sm m-t-10 waves-effect" onclick="self.history.back()"><i class="zmdi zmdi-close"></i> Cancel</button>
                    </div>

                </form>
            </div>
        </div>

<?php
    break;
    case "edit":
    $id         = $_GET['id'];
    $value      = $database->select($fields="*", $table="kontrak", $where_clause="WHERE id_kontrak = '$id'", $fetch="");
?>
        <div class="card">

            <div class="card-body card-padding">
            <p class="c-black f-500 m-b-20">Kontrak / Edit</p>
                <hr class="line">

                <form id="staff_gallery-form" method="post" enctype="multipart/form-data" action="<?php echo $aksi; ?>&act=update">
                    <div class="row">
                        <input type="hidden" name="id" value="<?php echo $id; ?>">
                        <div class="col-md-6">
                            <div class="form-group">
                                <div class="fg-line">
                                    <label>Nama</label>
                                    <input type="text" name="nama" class="form-control" placeholder="Masukkan nama" value="<?php echo $value['nama']; ?>">
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="form-group kaki">
                        <button type="submit" class="btn btn-primary btn-sm m-t-10 waves-effect"><i class="zmdi zmdi-check"></i> Save</button>
                        <button type="button" class="btn btn-danger btn-sm m-t-10 waves-effect" onclick="self.history.back()"><i class="zmdi zmdi-close"></i> Cancel</button>
                    </div>

                </form>

            </div>
        </div>
<?php
    break;
    }
?>