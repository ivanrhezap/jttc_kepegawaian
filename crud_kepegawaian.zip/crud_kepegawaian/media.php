<?php
    require_once "config.php";
?>

<!DOCTYPE html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?php echo $config['web_name']; ?></title>

    <!-- Icon -->
    <link rel="shortcut icon" href="assets/img/icons/icon.png">

    <!-- Vendor CSS -->
    <link href="assets/vendors/bower_components/animate.css/animate.min.css" rel="stylesheet">
    <link href="assets/vendors/bower_components/material-design-iconic-font/dist/css/material-design-iconic-font.min.css" rel="stylesheet">
    <link href="assets/vendors/bower_components/bootstrap-select/dist/css/bootstrap-select.css" rel="stylesheet">

    <!-- CSS -->
    <link href="assets/css/mdl.app.css" rel="stylesheet">
    <link href="assets/css/mdl.app.min.css" rel="stylesheet">

    <!-- Custom CSS Style -->
    <link href="assets/css/custom.css" rel="stylesheet">

    <!-- Javascript Libraries -->
    <script src="assets/vendors/bower_components/jquery/dist/jquery.min.js"></script>
    <script src="assets/vendors/bower_components/bootstrap/dist/js/bootstrap.min.js"></script>
    <script src="assets/vendors/bower_components/jquery.nicescroll/jquery.nicescroll.min.js"></script>
    <script src="assets/vendors/bower_components/Waves/dist/waves.min.js"></script>
    <script src="assets/vendors/bower_components/bootstrap-select/dist/js/bootstrap-select.js"></script>
    <!-- <script src="assets/vendors/bower_components/bootstrap-sweetalert/lib/sweet-alert.min.js"></script> -->

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/css/all.min.css" integrity="sha512-+4zCK9k+qNFUR5X+cKL9EIR+ZOhtIloNl9GIKS57V1MyNsYpYcUrUeQc9vNfzsWfV28IaLL3i96P9sdNyeRssA==" crossorigin="anonymous" />
</head>
<body class="sw-toggled">
    <header id="header">
        <ul class="header-inner">
            <li id="menu-trigger" data-trigger="#sidebar">
                <div class="line-wrap">
                    <div class="line top"></div>
                    <div class="line center"></div>
                    <div class="line bottom"></div>
                </div>
            </li>

            <li class="logo hidden-xs">
                <a href="?module=home"><?php echo $config['web_name']; ?></a>
            </li>
        </ul>
    </header>

    <section id="main">
        <aside id="sidebar" >
            <div class="sidebar-inner c-overflow">
                <ul class="main-menu m-t-15">
                    <li><a href="?module=home"><i class="fas fa-home"></i>Beranda</a></li>
                    <li><a href="?module=pegawai"><i class="fas fa-user"></i>Pegawai</a></li>
                    <li><a href="?module=jabatan"><i class="fas fa-user"></i>Jabatan</a></li>
                    <li><a href="?module=kontrak"><i class="fas fa-user"></i>Kontrak</a></li>
                </ul>
            </div>
        </aside>

        <section id="content">
            <div class="container">
                <?php require "modul.php"; ?>
            </div>
        </section>
    </section>

    <footer id="footer">
        <?php echo $config['web_name']; ?>
    </footer>

    <script src="assets/vendors/bower_components/autosize/dist/autosize.min.js"></script>
    <script src="assets/vendors/fileinput/fileinput.min.js"></script>
    <script src="assets/vendors/input-mask/input-mask.min.js"></script>

    <script src="assets/js/functions.js"></script>
    <script src="assets/js/mdl.style.js"></script>
</body>
</html>