<?php
    if ($_GET['module']=='home'){
?>
    <div class="card">
        <div class="card-header">
            <h5>Beranda</h5>
            <hr class="line">
        </div>

        <div class="card-body card-padding">
            <div class="row">
                <div class="col-sm-12">
                    <h3 class="m-t-0">Selamat Datang di halaman <?php echo $config['web_name'];?>.</h3>
                </div>
            </div>
        </div>
    </div>
<?php
    }
    
    elseif ($_GET['module']=='pegawai') {
        include "modul/mod_pegawai/pegawai_v.php";
    }

    elseif ($_GET['module']=='jabatan') {
        include "modul/mod_jabatan/jabatan_v.php";
    }

    elseif ($_GET['module']=='kontrak') {
        include "modul/mod_kontrak/kontrak_v.php";
    }

else{
    echo '<p><b><center>Halaman Tidak Ditemukan</center></b></p>';
}
?>