<?php
	require_once '../josys/db_connect.php';
	include_once '../josys/class/Database.php';

	$database 	= new Database($db);

	$config['web_name']     = 'JTTC Kepegawaian - CRUD';
?>